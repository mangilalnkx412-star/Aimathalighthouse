AAI MATHA LIGHT HOUSE — OWNER SMS ORDER ALERT SETUP

Goal
- When the customer submits an order, send order details by normal SMS to the shop number +91 81063 93073.
- Do not open WhatsApp for the customer.
- Exotel credentials stay on the server (Netlify Function), not in browser HTML.

Files
1) netlify/functions/send-order-sms.js — server-side SMS function
2) netlify.toml — tells Netlify where the function lives
3) frontend-integration.js — helper to call from the existing Place Order code

Before it can send real SMS
1. Create/sign into an Exotel account and enable SMS API for your account.
2. Complete India DLT registration as required by TRAI/provider: Principal Entity ID, approved Sender ID/header, and an approved message template ID. The exact template must match the order-alert SMS format. Confirm with Exotel whether the chosen account supports the required service/transactional category.
3. In Netlify, open the site → Site configuration → Environment variables. Add:
   EXOTEL_API_KEY = your Exotel API key
   EXOTEL_API_TOKEN = your Exotel API token
   EXOTEL_ACCOUNT_SID = your Exotel Account SID
   EXOTEL_FROM = your approved sender ID/header (or provider-approved ExoPhone)
   EXOTEL_DLT_ENTITY_ID = your DLT Principal Entity ID
   EXOTEL_DLT_TEMPLATE_ID = your approved template ID
4. Redeploy the site after setting environment variables.
5. Copy the `netlify` folder and `netlify.toml` into the same repository/deployment as the website. The website must be deployed on Netlify for this function URL to work. GitHub Pages alone cannot run Netlify Functions.
6. Add the helper from frontend-integration.js inside the existing index.html script.
7. In your existing Place Order handler, after form/cart validation, call `notifyShopBySms({...})` with the actual order fields (see example in the JS file). Remove any `window.open('https://wa.me/...')` call from that COD/online order handler if you do not want customer WhatsApp to open.
8. Test with a small test order. Check Netlify function logs and Exotel SMS logs.

Important
- Do not paste API key/token into index.html or send them to anyone.
- Do not use customer-submitted text as SMS recipient; this function always sends to +91 81063 93073.
- An accepted API request is not proof of delivery. Check provider delivery status/logs.
- Online UPI QR selection does NOT prove payment was made. Verify payment in your UPI app before treating the order as paid/dispatching it.
- DLT template IDs and sender IDs are account-specific; do not copy sample IDs from tutorials.
- The helper must be wired into the actual Place Order handler in your existing website; it cannot be safely auto-wired without editing that exact checkout function.
