/*
Add this helper inside your existing index.html <script>.
Call it ONLY after your website has generated/accepted the order.
This does not open WhatsApp. The shop owner receives an SMS notification.
*/
async function notifyShopBySms(order) {
  const response = await fetch('/.netlify/functions/send-order-sms', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(order)
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result.ok) {
    throw new Error(result.message || 'Order submitted, but SMS notification failed.');
  }
  return result;
}

/*
Example call after you have collected customer/cart values:

await notifyShopBySms({
  orderId: 'ORD-' + Date.now(),
  name: customerName,
  phone: customerPhone,
  address: customerAddress,
  paymentMethod: selectedPaymentMethod, // e.g. COD or UPI QR
  items: cartItemsSummary,              // e.g. "LED Bulb x 2, Ceiling Light x 1"
  total: finalTotal                     // numeric/string total in INR
});

IMPORTANT: put this call into your existing Place Order handler, after validation.
Do not show "SMS sent" unless this function returns ok:true. API accepted means queued,
not necessarily delivered. Keep your existing order/cart functions and do not replace
all of index.html with this helper.
*/
