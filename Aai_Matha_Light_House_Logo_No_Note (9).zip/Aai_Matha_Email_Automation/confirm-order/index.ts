import { createClient } from "npm:@supabase/supabase-js@2";
const corsHeaders = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
function reply(status: number, body: Record<string, unknown>) { return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } }); }
Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return reply(405, { ok: false, error: "Only POST requests are allowed." });
  const url = Deno.env.get("SUPABASE_URL"), anonKey = Deno.env.get("SUPABASE_ANON_KEY"), serviceKey = Deno.env.get("ORDER_SERVICE_ROLE_KEY"), resendKey = Deno.env.get("RESEND_API_KEY"), emailFrom = Deno.env.get("EMAIL_FROM");
  if (!url || !anonKey || !serviceKey || !resendKey || !emailFrom) return reply(500, { ok: false, error: "Missing Supabase or email secrets. Configure SUPABASE_ANON_KEY, ORDER_SERVICE_ROLE_KEY, RESEND_API_KEY and EMAIL_FROM." });
  const authHeader = req.headers.get("Authorization") || "";
  const token = authHeader.replace(/^Bearer\s+/i, "");
  if (!token) return reply(401, { ok: false, error: "Admin login required." });
  const authClient = createClient(url, anonKey, { global: { headers: { Authorization: `Bearer ${token}` } }, auth: { persistSession: false, autoRefreshToken: false } });
  const { data: userData, error: userError } = await authClient.auth.getUser(token);
  if (userError || !userData.user) return reply(401, { ok: false, error: "Admin login required." });
  const db = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: admin, error: adminError } = await db.from("admin_users").select("user_id").eq("user_id", userData.user.id).maybeSingle();
  if (adminError || !admin) return reply(403, { ok: false, error: "This account is not authorized to confirm orders." });
  try {
    const body = await req.json();
    const id = Number(body.id);
    const deliveryDate = String(body.deliveryDate || "");
    if (!Number.isSafeInteger(id) || id <= 0 || !/^\d{4}-\d{2}-\d{2}$/.test(deliveryDate)) return reply(400, { ok: false, error: "Choose a valid delivery date." });
    const { data: order, error: fetchError } = await db.from("orders").select("id, order_id, customer_name, customer_email, customer_address, items, total, payment_method, status, delivery_date").eq("id", id).maybeSingle();
    if (fetchError || !order) return reply(404, { ok: false, error: "Order not found." });
    if (!order.customer_email) return reply(400, { ok: false, error: "This order has no customer email. Ask the customer to place a new order with an email address." });
    const { error: updateError } = await db.from("orders").update({ status: "Confirmed", delivery_date: deliveryDate }).eq("id", id);
    if (updateError) return reply(500, { ok: false, error: "Could not update order status and delivery date." });
    const safeItems = Array.isArray(order.items) ? order.items.map((i: any) => `${String(i.name || "Item")} × ${Number(i.quantity) || 0}`).join("<br>") : "Order items";
    const prettyDate = new Date(`${deliveryDate}T12:00:00`).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric", timeZone: "Asia/Kolkata" });
    const html = `<div style="font-family:Arial,sans-serif;line-height:1.6;color:#172033"><h2>Order confirmed — Aai Matha Light House</h2><p>Hello ${String(order.customer_name || "Customer").replace(/[&<>"]/g, "").slice(0,100)},</p><p>Your order <strong>${String(order.order_id).replace(/[&<>"]/g, "")}</strong> has been confirmed.</p><p><strong>Expected delivery date:</strong> ${prettyDate}</p><p><strong>Items:</strong><br>${safeItems}</p><p><strong>Order total:</strong> ₹${Number(order.total).toFixed(2)}</p><p><strong>Delivery address:</strong> ${String(order.customer_address || "").replace(/[&<>"]/g, "")}</p><p>Thank you for shopping with Aai Matha Light House.</p></div>`;
    const response = await fetch("https://api.resend.com/emails", { method: "POST", headers: { Authorization: `Bearer ${resendKey}`, "Content-Type": "application/json" }, body: JSON.stringify({ from: emailFrom, to: [order.customer_email], subject: `Delivery date for order ${order.order_id}`, html }) });
    if (!response.ok) { const detail = await response.text(); console.error("Resend email failed:", detail); return reply(200, { ok: true, emailSent: false, emailError: "Order confirmed and date saved, but email service failed. Check Resend sender/domain settings and function logs." }); }
    return reply(200, { ok: true, emailSent: true, orderId: order.order_id, deliveryDate });
  } catch (error) { console.error("confirm-order error:", error); return reply(400, { ok: false, error: "Invalid confirmation request." }); }
});
