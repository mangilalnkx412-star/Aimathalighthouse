import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
function reply(status: number, body: Record<string, unknown>) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}
Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return reply(405, { ok: false, error: "Only POST requests are allowed." });
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const secretKey = Deno.env.get("ORDER_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !secretKey) return reply(500, { ok: false, error: "Order function secrets are not configured." });
  try {
    const body = await req.json();
    const name = String(body.name ?? "").trim().slice(0, 100);
    const phone = String(body.phone ?? "").replace(/\D/g, "");
    const email = String(body.email ?? "").trim().toLowerCase().slice(0, 254);
    const address = String(body.address ?? "").trim().slice(0, 500);
    const paymentMethod = body.paymentMethod;
    const rawItems = body.items;
    if (!name || !address || !/^\d{10}$/.test(phone)) return reply(400, { ok: false, error: "Enter a valid name, 10-digit mobile number and address." });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return reply(400, { ok: false, error: "Enter a valid email address." });
    if (!["COD", "ONLINE"].includes(paymentMethod)) return reply(400, { ok: false, error: "Invalid payment method." });
    if (!Array.isArray(rawItems) || rawItems.length < 1 || rawItems.length > 50) return reply(400, { ok: false, error: "Your cart is empty or contains invalid items." });
    const quantities = new Map<number, number>();
    for (const item of rawItems) {
      const productId = Number(item.productId), quantity = Number(item.quantity);
      if (!Number.isSafeInteger(productId) || productId <= 0 || !Number.isSafeInteger(quantity) || quantity < 1 || quantity > 100) return reply(400, { ok: false, error: "Invalid product or quantity." });
      const newQuantity = (quantities.get(productId) ?? 0) + quantity;
      if (newQuantity > 100) return reply(400, { ok: false, error: "Maximum quantity per product is 100." });
      quantities.set(productId, newQuantity);
    }
    const db = createClient(supabaseUrl, secretKey, { auth: { persistSession: false, autoRefreshToken: false } });
    const productIds = [...quantities.keys()];
    const { data: products, error: productError } = await db.from("products").select("id, name, price, image_url").in("id", productIds);
    if (productError) return reply(500, { ok: false, error: "Could not verify products." });
    if (!products || products.length !== productIds.length) return reply(400, { ok: false, error: "A selected product was not found." });
    const savedItems = products.map((product) => ({ productId: product.id, name: product.name, price: Number(product.price), quantity: quantities.get(Number(product.id))!, image_url: product.image_url || "" }));
    if (savedItems.some(item => !item.name || !Number.isFinite(item.price) || item.price < 0)) return reply(500, { ok: false, error: "A product has invalid pricing." });
    const subtotal = savedItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const deliveryCharge = subtotal >= 5000 ? 0 : 50;
    const total = Number((subtotal + deliveryCharge).toFixed(2));
    const orderId = "AAI-" + crypto.randomUUID().slice(0, 8).toUpperCase();
    const { error: orderError } = await db.from("orders").insert({ order_id: orderId, customer_name: name, customer_phone: phone, customer_email: email, customer_address: address, payment_method: paymentMethod, items: savedItems, total, status: "Pending", sms_status: "Not sent" });
    if (orderError) { console.error("Order insert failed:", orderError.message); return reply(500, { ok: false, error: "Order could not be saved." }); }
    return reply(201, { ok: true, orderId, subtotal, deliveryCharge, total, status: "Pending", message: "Order received. The shop will confirm it and email the expected delivery date." });
  } catch (error) { console.error("Order function error:", error); return reply(400, { ok: false, error: "Invalid order request." }); }
});
