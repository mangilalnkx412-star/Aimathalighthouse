-- Run once in Supabase SQL Editor. Safe to add these nullable columns if they do not exist yet.
alter table public.orders
  add column if not exists customer_email text,
  add column if not exists delivery_date date;
